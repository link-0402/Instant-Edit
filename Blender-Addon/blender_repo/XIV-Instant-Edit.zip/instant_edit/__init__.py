# Modified for XIV Instant Edit, 2026.
import bpy
from bpy.app.handlers import persistent

from .props  import set_addon_properties, remove_addon_properties, get_instant_edit_props
from .server import get_server_error, start_server, stop_server, poll_import_queue
from .recovery import cancel_recovery, schedule_recovery
from .revocation import cancel_revocations, schedule_revocations
from .cache import STALE_SECONDS, clean_cache, configure_cache


@persistent
def _recover_after_scene_load(_dummy) -> None:
    schedule_revocations()
    schedule_recovery()


def register() -> None:
    set_addon_properties()

    port = 42424
    try:
        from ..preferences import get_prefs
        prefs = get_prefs()
        port = prefs.instant_edit_blender_port
        configure_cache(
            bpy.path.abspath(prefs.instant_edit_cache_directory),
            prefs.instant_edit_auto_cleanup,
        )
        if prefs.instant_edit_auto_cleanup:
            clean_cache(STALE_SECONDS)
    except Exception:
        pass

    if not start_server(port):
        error = get_server_error() or "the port may already be in use"
        props = get_instant_edit_props()
        props.last_status = f"XIV Instant Edit listener unavailable on port {port}: {error}"
        print(props.last_status)
    bpy.app.timers.register(poll_import_queue, first_interval=1.0, persistent=True)
    if _recover_after_scene_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_recover_after_scene_load)
    schedule_recovery()
    schedule_revocations()


def unregister() -> None:
    if _recover_after_scene_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_recover_after_scene_load)
    cancel_recovery()
    cancel_revocations()
    stop_server()
    try:
        bpy.app.timers.unregister(poll_import_queue)
    except Exception:
        pass
    try:
        remove_addon_properties()
    except (AttributeError, RuntimeError):
        pass
